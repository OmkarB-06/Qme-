// ===================== APP =====================

function showView(name) {
  currentView = name;

  ['dashboard', 'trail', 'test', 'result', 'calendar'].forEach(v => {
    $('#view-' + v).classList.toggle('hidden', v !== name);
  });

  $$('.nav button').forEach(b =>
    b.classList.toggle('active', b.dataset.view === name)
  );

  if (name === 'dashboard') renderDashboard();
  if (name === 'trail') renderTrail();
  if (name === 'calendar') renderCalendar();
}

$$('.nav button').forEach(b => {
  b.addEventListener('click', () => showView(b.dataset.view));
});

// Start the app.
loadData();
showView('dashboard');
