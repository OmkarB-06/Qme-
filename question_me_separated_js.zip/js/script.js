/*
  Single entry point for the Question Me dashboard.
  If you use this file, remove the individual <script src="..."> tags
  and keep only: <script src="js/script.js"></script>
*/

const scripts = [
  'state.js',
  'storage.js',
  'question_data.js',
  'question_generator.js',
  'utils.js',
  'dashboard.js',
  'trail.js',
  'test.js',
  'result.js',
  'calendar.js',
  'app.js'
];

let index = 0;

function loadNextScript() {
  if (index >= scripts.length) return;

  const s = document.createElement('script');
  s.src = 'js/' + scripts[index++];
  s.onload = loadNextScript;
  s.onerror = () => console.error('Could not load js/' + scripts[index - 1]);
  document.body.appendChild(s);
}

loadNextScript();
