const STORE_KEY = 'climbiq-progress-v1';
let DATA = { levels: {}, attempts: [] }; // levels[n] = {bestPercent,bestCorrect,bestIncorrect,attempts,passed,lastDate}

async function loadData(){
  try{
    const res = await window.storage.get(STORE_KEY, false);
    if(res && res.value){ DATA = JSON.parse(res.value); }
  }catch(e){ /* no data yet */ }
  render();
}
async function saveData(){
  try{ await window.storage.set(STORE_KEY, JSON.stringify(DATA), false); }
  catch(e){ console.error('save failed', e); }
}
