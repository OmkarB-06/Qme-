function levelTier(level){ return Math.min(4, Math.ceil(level/5)); }
function levelName(level){
  const tier = levelTier(level);
  return ['Foundations','Building Speed','Advanced Reasoning','Placement-Ready'][tier-1];
}

function buildTest(level){
  const tier = levelTier(level);
  const questions = [];
  for(let i=0;i<5;i++){
    const q = genQuant(tier);
    questions.push({category:q.cat, qtext:q.qtext, code:null, lang:null, opts:q.opts, correctIndex:q.correctIndex});
  }
  const logicalPicks = pick(LOGICAL_POOL[tier], 5);
  logicalPicks.forEach(q=>{
    questions.push({category:'Logical Reasoning', qtext:q.qtext, code:null, lang:null, opts:q.opts.slice(), correctIndex:q.correctIndex});
  });
  const codePicks = pick(CODE_POOL[tier], 5);
  codePicks.forEach(q=>{
    questions.push({category:'Coding — '+q.lang, qtext:q.qtext, code:q.code, lang:q.lang, opts:q.opts.slice(), correctIndex:q.correctIndex});
  });
  return shuffle(questions);
}
