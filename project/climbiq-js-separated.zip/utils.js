/* Shared utility helpers */
function rnd(a,b){ return Math.floor(Math.random()*(b-a+1))+a; }
function shuffle(arr){ const a=arr.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }
function pick(arr,n){ return shuffle(arr).slice(0,n); }
function buildOptions(correctVal, distractors){
  const opts = shuffle([correctVal, ...distractors].map(String));
  const correctIndex = opts.indexOf(String(correctVal));
  return {opts, correctIndex};
}
function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
