function startTest(level){
  activeLevel = level;
  testQuestions = buildTest(level);
  userAnswers = new Array(15).fill(null);
  currentQIndex = 0;
  timeLeft = 15*60;
  showView('test');
  $('#test-title').textContent = 'Level '+level+' — '+levelName(level);
  renderJumpgrid();
  renderQuestion();
  if(timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(tick, 1000);
  updateTimerDisplay();
}
function tick(){
  timeLeft--;
  if(timeLeft<=0){ clearInterval(timerInterval); timeLeft=0; finishTest(); }
  updateTimerDisplay();
}
function updateTimerDisplay(){
  const m = Math.floor(timeLeft/60), s = timeLeft%60;
  const el = $('#timer');
  el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.classList.toggle('low', timeLeft<=60);
}
function renderQuestion(){
  const q = testQuestions[currentQIndex];
  $('#test-sub').textContent = `Question ${currentQIndex+1} of 15`;
  $('#progress-fill').style.width = ((currentQIndex+1)/15*100)+'%';
  const card = $('#qcard');
  let html = `<div class="qmeta">${q.category}</div><div class="qtext">${q.qtext}</div>`;
  if(q.code){ html += `<pre>${escapeHtml(q.code)}</pre>`; }
  q.opts.forEach((opt,i)=>{
    const sel = userAnswers[currentQIndex]===i;
    html += `<div class="opt ${sel?'selected':''}" data-i="${i}"><div class="letter">${String.fromCharCode(65+i)}</div><div class="otext">${escapeHtml(opt)}</div></div>`;
  });
  card.innerHTML = html;
  card.querySelectorAll('.opt').forEach(el=>{
    el.addEventListener('click', ()=>{
      userAnswers[currentQIndex] = parseInt(el.dataset.i);
      renderQuestion();
      renderJumpgrid();
    });
  });
  $('#btn-prev').disabled = currentQIndex===0;
  $('#btn-prev').style.opacity = currentQIndex===0 ? .4 : 1;
}
function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function renderJumpgrid(){
  const g = $('#jumpgrid');
  g.innerHTML='';
  for(let i=0;i<15;i++){
    const b = document.createElement('div');
    b.className = 'jbtn ' + (userAnswers[i]!==null?'answered':'') + (i===currentQIndex?' current':'');
    b.textContent = i+1;
    b.addEventListener('click', ()=>{ currentQIndex=i; renderQuestion(); renderJumpgrid(); });
    g.appendChild(b);
  }
}
$('#btn-prev').addEventListener('click', ()=>{ if(currentQIndex>0){ currentQIndex--; renderQuestion(); renderJumpgrid(); } });
$('#btn-next').addEventListener('click', ()=>{ if(currentQIndex<14){ currentQIndex++; renderQuestion(); renderJumpgrid(); } });
$('#btn-submit').addEventListener('click', ()=>{
  if(confirm('Submit the test now?')) finishTest();
});

async function finishTest(){
  if(timerInterval) clearInterval(timerInterval);
  let correct=0, incorrect=0, unattempted=0;
  const reviews=[];
  testQuestions.forEach((q,i)=>{
    const ans = userAnswers[i];
    if(ans===null){ unattempted++; }
    else if(ans===q.correctIndex){ correct++; }
    else { incorrect++; }
    reviews.push({q, ans});
  });
  const marks = correct;
  const percent = Math.round((correct/15)*1000)/10;
  const grade = gradeFor(percent);
  const passed = percent>=40;

  const today = new Date();
  const dateStr = today.toISOString().slice(0,10);
  DATA.attempts.push({level:activeLevel, date:dateStr, correct, incorrect, unattempted, percent, grade});
  const info = DATA.levels[activeLevel] || {bestPercent:0,bestCorrect:0,bestIncorrect:0,attempts:0,passed:false};
  info.attempts = (info.attempts||0)+1;
  info.lastDate = dateStr;
  if(percent >= (info.bestPercent||0)){
    info.bestPercent = percent;
    info.bestCorrect = correct;
    info.bestIncorrect = incorrect;
  }
  if(passed) info.passed = true;
  DATA.levels[activeLevel] = info;
  await saveData();

  lastResult = {correct, incorrect, unattempted, marks, percent, grade, passed, reviews};
  renderResult();
  showView('result');
}
function gradeFor(pct){
  if(pct>=90) return 'A+';
  if(pct>=75) return 'A';
  if(pct>=60) return 'B';
  if(pct>=40) return 'C';
  return 'F';
}
function renderResult(){
  const r = lastResult;
  $('#result-grade').textContent = r.grade;
  $('#result-grade').style.borderColor = r.passed ? 'var(--accent-teal)' : 'var(--accent-coral)';
  $('#result-grade').style.color = r.passed ? 'var(--accent-teal)' : 'var(--accent-coral)';
  $('#result-title').textContent = r.passed ? `Level ${activeLevel} cleared!` : `Level ${activeLevel} — not cleared yet`;
  $('#result-sub').textContent = r.passed ? (activeLevel<20 ? 'Level '+(activeLevel+1)+' is now unlocked.' : 'You have conquered the final level!') : 'Score 40% or higher to unlock the next level. Try again!';
  $('#r-correct').textContent = r.correct;
  $('#r-incorrect').textContent = r.incorrect;
  $('#r-unattempted').textContent = r.unattempted;
  $('#r-marks').textContent = r.marks+' / 15';
  $('#r-percent').textContent = r.percent+'%';
  $('#review-list').classList.add('hidden');
  $('#btn-review-toggle').textContent = 'Review Answers';
  const list = $('#review-list');
  list.innerHTML = r.reviews.map((item,idx)=>{
    const correctText = item.q.opts[item.q.correctIndex];
    const yourText = item.ans!==null ? item.q.opts[item.ans] : '— not answered —';
    const isRight = item.ans===item.q.correctIndex;
    return `<div class="review-item">
      <div class="qmeta" style="font-size:10.5px;color:var(--text-faint);text-transform:uppercase;margin-bottom:6px;">Q${idx+1} · ${item.q.category}</div>
      <div class="qtext">${escapeHtml(item.q.qtext)}</div>
      ${item.q.code?`<pre>${escapeHtml(item.q.code)}</pre>`:''}
      <div class="ans-line ${isRight?'correct':'wrong'}">Your answer: ${escapeHtml(yourText)}</div>
      ${!isRight?`<div class="ans-line correct">Correct answer: ${escapeHtml(correctText)}</div>`:''}
    </div>`;
  }).join('');
}
$('#btn-review-toggle').addEventListener('click', ()=>{
  const list = $('#review-list');
  const hidden = list.classList.toggle('hidden');
  $('#btn-review-toggle').textContent = hidden ? 'Review Answers' : 'Hide Review';
});
$('#btn-back-trail').addEventListener('click', ()=> showView('trail'));
