# ClimbIQ — Separated JavaScript

The original `function.docx` contained the application's JavaScript in one large file. It has been separated into focused files while keeping the existing global-script architecture (no bundler required).

## Files

1. `storage.js` — progress loading/saving
2. `utils.js` — shared helpers (`rnd`, `shuffle`, `pick`, `buildOptions`, `escapeHtml`)
3. `question-generator.js` — procedural quantitative question generation
4. `question-data.js` — question bank plus derived logical/coding pools
5. `question-engine.js` — level/tier logic and test construction
6. `state.js` — application state, DOM helpers, and view switching
7. `dashboard.js` — dashboard rendering
8. `trail.js` — level trail and level overlay
9. `test.js` — test timer, questions, navigation, submission, results
10. `calendar.js` — calendar and attempt history
11. `app.js` — final event wiring and application startup

## HTML script order

Because these are regular scripts and share the existing global variables/functions, load them in this exact order:

```html
<script src="js/storage.js"></script>
<script src="js/utils.js"></script>
<script src="js/question-generator.js"></script>
<script src="js/question-data.js"></script>
<script src="js/question-engine.js"></script>
<script src="js/state.js"></script>
<script src="js/dashboard.js"></script>
<script src="js/trail.js"></script>
<script src="js/test.js"></script>
<script src="js/calendar.js"></script>
<script src="js/app.js"></script>
```

## Important note

The supplied source calls `LOGICAL_POOL` and `CODE_POOL` from `buildTest()` but does not explicitly define those arrays in the original combined file. The separated `question-data.js` creates those pools from the existing `QUESTION_POOL` so the split version has the data structures that the existing test builder expects.

No external libraries or build tools are required by these JS files.
