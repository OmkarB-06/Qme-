let currentView = 'dashboard';
let activeLevel = null;
let testQuestions = [];
let userAnswers = [];
let currentQIndex = 0;
let timeLeft = 15*60;
let timerInterval = null;
let calMonth = new Date().getMonth();
let calYear = new Date().getFullYear();
let lastResult = null;

const $ = sel => document.querySelector(sel);
const $$ = sel => document.querySelectorAll(sel);

function showView(name){
  currentView = name;
  ['dashboard','trail','test','result','calendar'].forEach(v=>{
    $('#view-'+v).classList.toggle('hidden', v!==name);
  });
  $$('.nav button').forEach(b=> b.classList.toggle('active', b.dataset.view===name));
  if(name==='dashboard') renderDashboard();
  if(name==='trail') renderTrail();
  if(name==='calendar') renderCalendar();
}

$$('.nav button').forEach(b=>{
  b.addEventListener('click', ()=> showView(b.dataset.view));
});
