/* Application bootstrap — load this file last */
$$('.nav button').forEach(b=>{
  b.addEventListener('click', ()=> showView(b.dataset.view));
});

loadData();
